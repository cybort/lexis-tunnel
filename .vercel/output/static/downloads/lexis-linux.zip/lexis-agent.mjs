#!/usr/bin/env node
/**
 * LEXIS resident agent. Same lexis.config.json on Windows, Linux, and Android (Termux).
 * Fixed-port mode listens for SOCKS, plain TCP maps, and an encrypted tunnel.
 * The tunnel is LEXIS2: HMAC token handshake, then AES-256-GCM frames.
 * A token shorter than 8 characters makes the tunnel refuse every peer.
 * Codebook sealing stays in the console; this process does not speak it.
 */
import { execFile } from "node:child_process";
import { createHmac, hkdfSync, randomBytes, createCipheriv, createDecipheriv, timingSafeEqual } from "node:crypto";
import { lookup } from "node:dns";
import { createServer as createTcp, connect as connectTcp } from "node:net";
import { createServer as createHttp } from "node:http";
import { mkdirSync, readFileSync, writeFileSync, existsSync, readdirSync, readlinkSync } from "node:fs";
import { homedir, platform } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const configPath = process.argv.includes("--config")
  ? process.argv[process.argv.indexOf("--config") + 1]
  : join(here, "lexis.config.json");

const GEOSITE = {
  private: ["localhost", "local", "localdomain", "invalid"],
  cn: ["cn", "baidu.com", "qq.com", "taobao.com", "aliyun.com", "bilibili.com", "jd.com"],
  google: ["google.com", "gstatic.com", "googleapis.com", "youtube.com", "gmail.com"],
  telegram: ["telegram.org", "t.me", "telegra.ph"],
};
const GEOIP = {
  private: ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "169.254.0.0/16"],
  cn: ["114.114.114.114/32", "223.5.5.5/32", "119.29.29.29/32", "180.76.76.76/32"],
};

const started = Date.now();
const state = {
  config: null,
  listeners: [],
  beats: 0,
  lastBeat: 0,
  decisions: [],
  system: "固定端口，未请求系统接管",
  resources: "未配置远程词表",
  errors: [],
};
let remoteGeosite = "";
let remoteGeoip = "";
let liveConns = 0;

function log(line) {
  const text = `${new Date().toISOString()} ${line}`;
  if (state.config?.logLevel === "debug" || !line.startsWith("debug")) console.log(text);
}

function loadConfig() {
  const raw = JSON.parse(readFileSync(configPath, "utf8"));
  if (!raw || raw.version !== 1) throw new Error("lexis.config.json 版本不是 1");
  return raw;
}

function absorb(geosite, geoip, text, fallback) {
  const cidr = (value) => /^\d{1,3}(\.\d{1,3}){3}\/\d{1,2}$/.test(value);
  for (const line of String(text || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const [head, ...rest] = trimmed.split(/\s+/);
    const value = rest.join(" ");
    if (!head) continue;
    if (head.toLowerCase().startsWith("geoip:")) {
      const tag = head.slice(6).toLowerCase();
      if (tag && value) geoip[tag] = [...(geoip[tag] || []), value];
      continue;
    }
    if (!value) {
      if (fallback === "geoip" && head.includes("/")) geoip.remote = [...(geoip.remote || []), head];
      else if (fallback === "geosite") geosite.remote = [...(geosite.remote || []), head.toLowerCase()];
      continue;
    }
    if (fallback === "geoip" && cidr(value)) {
      geoip[head.toLowerCase()] = [...(geoip[head.toLowerCase()] || []), value];
      continue;
    }
    if (fallback === "geoip") continue;
    geosite[head.toLowerCase()] = [...(geosite[head.toLowerCase()] || []), value.toLowerCase()];
  }
}

function lists(config) {
  const geosite = Object.fromEntries(Object.entries(GEOSITE).map(([k, v]) => [k, [...v]]));
  const geoip = Object.fromEntries(Object.entries(GEOIP).map(([k, v]) => [k, [...v]]));
  absorb(geosite, geoip, config.extras, "");
  absorb(geosite, geoip, remoteGeosite, "geosite");
  absorb(geosite, geoip, remoteGeoip, "geoip");
  return { geosite, geoip };
}

async function pullText(url) {
  const res = await fetch(url, { signal: AbortSignal.timeout(4000), redirect: "follow" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  if (text.length > 512 * 1024) throw new Error("超过 512KB");
  return text;
}

async function pullResources(config) {
  const jobs = [
    ["geosite", config.geositeUrl],
    ["geoip", config.geoipUrl],
  ];
  const notes = [];
  for (const [kind, url] of jobs) {
    if (!url || !/^https?:\/\//i.test(String(url))) continue;
    try {
      const text = await pullText(url);
      if (kind === "geosite") remoteGeosite = text;
      else remoteGeoip = text;
      notes.push(`${kind} ${text.length} 字节`);
      log(`已拉取 ${kind} ${text.length} 字节`);
    } catch (err) {
      const msg = `${kind} 未拉取：${err.message || err}`;
      state.errors.push(msg);
      notes.push(msg);
      log(msg);
    }
  }
  state.resources = notes.length ? notes.join(" · ") : "未配置远程词表";
}

function ip4(ip) {
  return ip.split(".").reduce((acc, part) => ((acc << 8) | Number(part)) >>> 0, 0);
}

function isIp(value) {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(value);
}

function cidrContains(cidr, ip) {
  const [base, bitsRaw] = cidr.split("/");
  if (!isIp(base) || !isIp(ip)) return false;
  const bits = bitsRaw === undefined ? 32 : Number(bitsRaw);
  if (!Number.isInteger(bits) || bits < 0 || bits > 32) return false;
  const mask = bits === 0 ? 0 : (~0 << (32 - bits)) >>> 0;
  return (ip4(base) & mask) === (ip4(ip) & mask);
}

function processHits(actual, ruleName) {
  const want = String(ruleName || "").trim().toLowerCase();
  if (!want) return false;
  const bare = String(actual || "").toLowerCase().replace(/\.exe$/, "");
  const wantBare = want.replace(/\.exe$/, "");
  return bare === wantBare || bare.includes(wantBare);
}

function decide(config, query) {
  const book = lists(config);
  const host = String(query.host || "").toLowerCase().replace(/\.$/, "");
  const ip = query.ip || (isIp(host) ? host : "");
  const processName = String(query.process || "").toLowerCase();
  if (processName) {
    const named = (config.processes || []).find((item) => processHits(processName, item.name));
    if (named) return { action: named.action, reason: `程序 ${named.name}` };
  }
  for (const rule of config.rules || []) {
    const value = String(rule.value || "").trim().toLowerCase();
    let hit = false;
    if (rule.type === "MATCH") hit = true;
    else if (rule.type === "DOMAIN") hit = host === value;
    else if (rule.type === "DOMAIN-SUFFIX") hit = host === value || host.endsWith(`.${value}`);
    else if (rule.type === "DOMAIN-KEYWORD") hit = value && host.includes(value);
    else if (rule.type === "IP-CIDR") hit = ip && cidrContains(rule.value.trim(), ip);
    else if (rule.type === "GEOIP") hit = ip && (book.geoip[value] || []).some((cidr) => cidrContains(cidr, ip));
    else if (rule.type === "GEOSITE") hit = host && (book.geosite[value] || []).some((domain) => host === domain || host.endsWith(`.${domain}`));
    else if (rule.type === "PROCESS-NAME") hit = processName && processHits(processName, rule.value);
    else if (rule.type === "PORT") hit = String(query.port || "") === String(rule.value || "").trim();
    else if (rule.type === "NETWORK") hit = String(query.network || "tcp").toLowerCase() === value;
    if (hit) return { action: rule.action, reason: `${rule.type} ${rule.value}` };
  }
  return { action: config.processDefault || "proxy", reason: "默认" };
}

function note(decision, host) {
  state.decisions.unshift({ at: Date.now(), host, ...decision });
  state.decisions = state.decisions.slice(0, 12);
  log(`${decision.action} ${host} (${decision.reason})`);
}

function linkOf(config) {
  const link = config.link || {};
  const idle = Number(link.idleMs);
  const max = Number(link.maxConns);
  const header = Number(link.headerBytes);
  return {
    token: String(link.token || "").trim(),
    idleMs: Number.isInteger(idle) && idle >= 1000 ? idle : 120000,
    maxConns: Number.isInteger(max) && max >= 1 ? max : 128,
    headerBytes: Number.isInteger(header) && header >= 256 ? header : 8192,
    allowLan: link.allowLan === true,
  };
}

function arm(socket, config) {
  socket.setTimeout(linkOf(config).idleMs);
  socket.on("timeout", () => {
    log("空闲超时");
    socket.destroy();
  });
}

function admit(socket, config) {
  if (liveConns >= linkOf(config).maxConns) {
    log("连接数已满");
    socket.destroy();
    return false;
  }
  liveConns += 1;
  let closed = false;
  socket.once("close", () => {
    if (closed) return;
    closed = true;
    liveConns -= 1;
  });
  return true;
}

function ipv4Parts(ip) {
  const parts = String(ip).split(".");
  if (parts.length !== 4) return null;
  const nums = parts.map((part) => Number(part));
  if (nums.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return null;
  return nums;
}

function expandV6(ip) {
  let text = ip.toLowerCase();
  const dotted = text.match(/^(.*:)(\d+\.\d+\.\d+\.\d+)$/);
  if (dotted) {
    const nums = ipv4Parts(dotted[2]);
    if (!nums) return null;
    const tail = ((nums[0] << 8) | nums[1]).toString(16) + ":" + ((nums[2] << 8) | nums[3]).toString(16);
    text = dotted[1] + tail;
  }
  const halves = text.split("::");
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(":") : [];
  const tail = halves.length === 2 && halves[1] ? halves[1].split(":") : [];
  if (halves.length === 1 && head.length !== 8) return null;
  const missing = 8 - head.length - tail.length;
  if (missing < 0) return null;
  const full = [...head, ...Array(missing).fill("0"), ...tail];
  if (full.length !== 8 || full.some((part) => !/^[0-9a-f]{1,4}$/.test(part))) return null;
  return full.map((part) => part.padStart(4, "0")).join(":");
}

function isBlockedV4(ip) {
  if (!ipv4Parts(ip)) return true;
  const nets = [
    ["0.0.0.0", 8],
    ["10.0.0.0", 8],
    ["100.64.0.0", 10],
    ["127.0.0.0", 8],
    ["169.254.0.0", 16],
    ["172.16.0.0", 12],
    ["192.0.0.0", 24],
    ["192.0.2.0", 24],
    ["192.168.0.0", 16],
    ["198.18.0.0", 15],
    ["198.51.100.0", 24],
    ["203.0.113.0", 24],
    ["224.0.0.0", 4],
    ["240.0.0.0", 4],
  ];
  return nets.some(([base, bits]) => cidrContains(`${base}/${bits}`, ip));
}

function isBlockedAddress(ip) {
  let raw = String(ip || "").trim().toLowerCase();
  if (raw.startsWith("[") && raw.endsWith("]")) raw = raw.slice(1, -1);
  if (raw.startsWith("::ffff:") && ipv4Parts(raw.slice(7))) return isBlockedV4(raw.slice(7));
  if (ipv4Parts(raw)) return isBlockedV4(raw);
  if (!raw.includes(":")) return true;
  const expanded = expandV6(raw);
  if (!expanded) return true;
  if (expanded === "0000:0000:0000:0000:0000:0000:0000:0000") return true;
  if (expanded === "0000:0000:0000:0000:0000:0000:0000:0001") return true;
  const first = Number.parseInt(expanded.slice(0, 4), 16);
  if ((first & 0xfe00) === 0xfc00) return true;
  if ((first & 0xffc0) === 0xfe80) return true;
  if ((first & 0xff00) === 0xff00) return true;
  if (expanded.startsWith("2001:0db8")) return true;
  if (expanded.startsWith("0000:0000:0000:0000:0000:ffff:")) {
    const hex = expanded.split(":").slice(6).join("");
    const v4 = [0, 1, 2, 3].map((i) => Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16)).join(".");
    return isBlockedV4(v4);
  }
  return false;
}

function allowHit(config, host, port) {
  const name = String(host || "").trim().toLowerCase().replace(/^\[|\]$/g, "");
  const list = Array.isArray(config.egress?.allow) ? config.egress.allow : [];
  for (const raw of list) {
    const item = String(raw || "").trim().toLowerCase();
    if (!item) continue;
    if (item.includes("/")) {
      const base = item.split("/")[0];
      if (ipv4Parts(base) && ipv4Parts(name) && cidrContains(item, name)) return true;
      continue;
    }
    const bracket = item.match(/^\[(.+)\]:(\d+)$/);
    if (bracket) {
      if (bracket[1] === name && Number(bracket[2]) === Number(port)) return true;
      continue;
    }
    const colon = item.lastIndexOf(":");
    if (colon > 0 && item.indexOf(":") === colon && /^\d+$/.test(item.slice(colon + 1))) {
      if (item.slice(0, colon) === name && Number(item.slice(colon + 1)) === Number(port)) return true;
      continue;
    }
    if (item === name) return true;
  }
  return false;
}

function lookupAll(host) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("dns")), 3000);
    lookup(host, { all: true, verbatim: true }, (err, rows) => {
      clearTimeout(timer);
      if (err) reject(err);
      else resolve(rows || []);
    });
  });
}

async function assessTarget(config, host, port) {
  const name = String(host || "").trim();
  const nport = Number(port);
  if (!name || !Number.isInteger(nport) || nport < 1 || nport > 65535) return { ok: false, reason: "目标无效" };
  if (config.egress?.blockPrivate === false) return { ok: true, host: name, port: nport };
  if (allowHit(config, name, nport)) return { ok: true, host: name, port: nport };
  if (ipv4Parts(name) || name.includes(":")) {
    if (isBlockedAddress(name)) return { ok: false, reason: "目标地址被拦截" };
    return { ok: true, host: name, port: nport };
  }
  let addrs = [];
  try {
    addrs = await lookupAll(name);
  } catch {
    return { ok: false, reason: "域名无法解析" };
  }
  if (!addrs.length) return { ok: false, reason: "域名无法解析" };
  for (const addr of addrs) {
    if (isBlockedAddress(addr.address)) return { ok: false, reason: "解析到内网地址" };
  }
  return { ok: true, host: addrs[0].address, port: nport };
}

function hmacHex(token, label) {
  return createHmac("sha256", Buffer.from(token, "utf8")).update(label).digest("hex");
}

function hexEqual(a, b) {
  const left = Buffer.from(String(a || "").toLowerCase(), "utf8");
  const right = Buffer.from(String(b || "").toLowerCase(), "utf8");
  if (left.length === 0 || left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

function linkKeys(token, nonceC, nonceS) {
  const okm = Buffer.from(hkdfSync("sha256", Buffer.from(token, "utf8"), Buffer.concat([nonceC, nonceS]), "lexis-link-v1", 64));
  return { c2s: okm.subarray(0, 32), s2c: okm.subarray(32, 64) };
}

class SocketBuf {
  constructor(socket) {
    this.socket = socket;
    this.buf = Buffer.alloc(0);
    this.dead = null;
    this.ondata = () => {};
    socket.on("data", (chunk) => {
      this.buf = Buffer.concat([this.buf, chunk]);
      this.ondata();
    });
    socket.on("error", (err) => {
      this.dead = err;
      this.ondata();
    });
    socket.on("close", () => {
      this.dead = this.dead || new Error("连接关闭");
      this.ondata();
    });
  }
}

function readLinesFrom(sb, count, cap, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      sb.ondata = () => {};
      reject(new Error("握手超时"));
    }, timeoutMs);
    const check = () => {
      if (sb.buf.length > cap) {
        clearTimeout(timer);
        sb.ondata = () => {};
        reject(new Error("握手过长"));
        return;
      }
      const lines = [];
      let start = 0;
      for (let i = 0; i < sb.buf.length; i += 1) {
        if (sb.buf[i] !== 0x0a) continue;
        let end = i;
        if (end > start && sb.buf[end - 1] === 0x0d) end -= 1;
        lines.push(sb.buf.subarray(start, end).toString("utf8"));
        start = i + 1;
        if (lines.length === count) {
          clearTimeout(timer);
          sb.buf = Buffer.from(sb.buf.subarray(start));
          sb.ondata = () => {};
          resolve(lines);
          return;
        }
      }
      if (sb.dead) {
        clearTimeout(timer);
        sb.ondata = () => {};
        reject(sb.dead);
      }
    };
    sb.ondata = check;
    check();
  });
}

class FrameLink {
  constructor(sb, keys, role) {
    this.sb = sb;
    this.socket = sb.socket;
    this.writeKey = role === "client" ? keys.c2s : keys.s2c;
    this.readKey = role === "client" ? keys.s2c : keys.c2s;
    this.writeDir = role === "client" ? 1 : 2;
    this.readDir = role === "client" ? 2 : 1;
    this.wseq = 1;
    this.rseq = 1;
    this.waiters = [];
    this.failed = null;
    sb.ondata = () => this.pump();
    this.pump();
  }

  fail(err) {
    if (this.failed) return;
    this.failed = err instanceof Error ? err : new Error(String(err));
    this.sb.ondata = () => {};
    this.socket.destroy();
    while (this.waiters.length) this.waiters.shift().reject(this.failed);
  }

  tryTake() {
    if (this.sb.buf.length < 4) return null;
    const len = this.sb.buf.readUInt32BE(0);
    if (len < 28 || len > 12 + 16 + 65536) throw new Error("帧长度无效");
    if (this.sb.buf.length < 4 + len) return null;
    const body = this.sb.buf.subarray(4, 4 + len);
    this.sb.buf = Buffer.from(this.sb.buf.subarray(4 + len));
    const iv = body.subarray(0, 12);
    const tag = body.subarray(body.length - 16);
    const ct = body.subarray(12, body.length - 16);
    const decipher = createDecipheriv("aes-256-gcm", this.readKey, iv);
    const aad = Buffer.alloc(5);
    aad[0] = this.readDir;
    aad.writeUInt32BE(this.rseq, 1);
    decipher.setAAD(aad);
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(ct), decipher.final()]);
    this.rseq += 1;
    return plain;
  }

  pump() {
    if (this.failed) return;
    if (this.sb.buf.length > 1024 * 1024) {
      this.fail(new Error("缓冲过大"));
      return;
    }
    try {
      while (this.waiters.length) {
        const frame = this.tryTake();
        if (!frame) break;
        this.waiters.shift().resolve(frame);
      }
    } catch (err) {
      this.fail(err);
      return;
    }
    if (this.sb.dead && this.waiters.length) this.fail(this.sb.dead);
  }

  readFrame() {
    if (this.failed) return Promise.reject(this.failed);
    try {
      const frame = this.tryTake();
      if (frame) return Promise.resolve(frame);
    } catch (err) {
      this.fail(err);
      return Promise.reject(err);
    }
    if (this.sb.dead) return Promise.reject(this.sb.dead);
    return new Promise((resolve, reject) => this.waiters.push({ resolve, reject }));
  }

  writeFrame(plain) {
    const data = Buffer.isBuffer(plain) ? plain : Buffer.from(String(plain));
    if (data.length > 65536) {
      let ok = true;
      for (let i = 0; i < data.length; i += 65536) ok = this.writeFrame(data.subarray(i, i + 65536)) && ok;
      return ok;
    }
    const iv = randomBytes(12);
    const cipher = createCipheriv("aes-256-gcm", this.writeKey, iv);
    const aad = Buffer.alloc(5);
    aad[0] = this.writeDir;
    aad.writeUInt32BE(this.wseq, 1);
    cipher.setAAD(aad);
    const ct = Buffer.concat([cipher.update(data), cipher.final()]);
    const tag = cipher.getAuthTag();
    const body = Buffer.concat([iv, ct, tag]);
    const head = Buffer.alloc(4);
    head.writeUInt32BE(body.length);
    this.wseq += 1;
    return this.socket.write(Buffer.concat([head, body]));
  }
}

async function openLink(socket, config) {
  const link = linkOf(config);
  if (link.token.length < 8) throw new Error("令牌不足 8 个字符");
  const sb = new SocketBuf(socket);
  const nonceC = randomBytes(16);
  const nonceHex = nonceC.toString("hex");
  socket.write(`LEXIS2\n${nonceHex}\n${hmacHex(link.token, `lexis-c|${nonceHex}`)}\n`);
  const lines = await readLinesFrom(sb, 2, link.headerBytes, 10000);
  const nonceSHex = String(lines[0] || "").toLowerCase();
  if (!/^[0-9a-f]{32}$/.test(nonceSHex) || !hexEqual(hmacHex(link.token, `lexis-s|${nonceHex}|${nonceSHex}`), lines[1])) {
    throw new Error("对端鉴权失败");
  }
  return new FrameLink(sb, linkKeys(link.token, nonceC, Buffer.from(nonceSHex, "hex")), "client");
}

async function clientSession(socket, token, headerBytes = 8192) {
  return openLink(socket, { link: { token, headerBytes } });
}

async function acceptLink(socket, config) {
  const link = linkOf(config);
  const sb = new SocketBuf(socket);
  const lines = await readLinesFrom(sb, 3, link.headerBytes, 10000);
  const nonceHex = String(lines[1] || "").toLowerCase();
  const mac = String(lines[2] || "").toLowerCase();
  if (lines[0] !== "LEXIS2" || !/^[0-9a-f]{32}$/.test(nonceHex) || !/^[0-9a-f]{64}$/.test(mac)) throw new Error("握手格式不对");
  if (!hexEqual(hmacHex(link.token, `lexis-c|${nonceHex}`), mac)) throw new Error("鉴权失败");
  const nonceS = randomBytes(16);
  const nonceSHex = nonceS.toString("hex");
  socket.write(`${nonceSHex}\n${hmacHex(link.token, `lexis-s|${nonceHex}|${nonceSHex}`)}\n`);
  return new FrameLink(sb, linkKeys(link.token, Buffer.from(nonceHex, "hex"), nonceS), "server");
}

function bridgePlain(session, plain) {
  const enc = session.socket;
  const die = () => {
    plain.destroy();
    enc.destroy();
  };
  plain.on("error", die);
  enc.on("error", die);
  plain.on("close", () => enc.destroy());
  enc.on("close", () => plain.destroy());
  plain.on("data", (chunk) => {
    try {
      if (!session.writeFrame(chunk)) plain.pause();
    } catch {
      die();
    }
  });
  enc.on("drain", () => plain.resume());
  plain.on("drain", () => enc.resume());
  plain.resume();
  const pull = async () => {
    try {
      for (;;) {
        const frame = await session.readFrame();
        if (!plain.write(frame)) enc.pause();
      }
    } catch {
      die();
    }
  };
  void pull();
}

const SOCKS_OK = Buffer.from([0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0]);
const SOCKS_FAIL = Buffer.from([0x05, 0x05, 0x00, 0x01, 0, 0, 0, 0, 0, 0]);

function okSocks(socket) {
  if (!socket._lexisSocks || socket._lexisReplied) return;
  socket._lexisReplied = true;
  socket.write(SOCKS_OK);
}

function failSocks(socket) {
  if (socket.destroyed) return;
  if (socket._lexisSocks && !socket._lexisReplied) {
    socket._lexisReplied = true;
    socket.end(SOCKS_FAIL);
    return;
  }
  socket.destroy();
}

function pipe(a, b) {
  a.resume();
  b.resume();
  a.pipe(b);
  b.pipe(a);
  const close = () => {
    a.destroy();
    b.destroy();
  };
  a.on("error", close);
  b.on("error", close);
  a.on("close", () => b.destroy());
  b.on("close", () => a.destroy());
}

function dial(host, port, config) {
  const socket = connectTcp({ host, port });
  arm(socket, config);
  return socket;
}

function relayProxy(socket, config, host, port) {
  if (linkOf(config).token.length < 8) {
    log(`接入 ${host}:${port} 失败：链路令牌不足 8 个字符`);
    failSocks(socket);
    return;
  }
  const endpoint = String(config.peerEndpoint || "");
  const match = endpoint.match(/^(.+):(\d+)$/);
  if (!match) {
    log(`接入 ${host}:${port} 失败：没有对端主机:端口`);
    failSocks(socket);
    return;
  }
  const peer = dial(match[1], Number(match[2]), config);
  peer.on("connect", () => {
    void (async () => {
      try {
        const session = await openLink(peer, config);
        session.writeFrame(`OPEN\n${host}\n${port}\n`);
        const reply = (await session.readFrame()).toString("utf8");
        if (!reply.startsWith("OK\n")) {
          log(`接入 ${host}:${port} 被拒绝 ${reply.trim()}`);
          failSocks(socket);
          peer.destroy();
          return;
        }
        okSocks(socket);
        bridgePlain(session, socket);
      } catch (err) {
        log(`接入 ${host}:${port} 失败：${err.message || err}`);
        failSocks(socket);
        peer.destroy();
      }
    })();
  });
  peer.on("error", () => failSocks(socket));
}

function relayDirect(socket, host, port, config) {
  const remote = dial(host, port, config);
  remote.on("connect", () => {
    okSocks(socket);
    pipe(socket, remote);
  });
  remote.on("error", () => {
    remote.destroy();
    failSocks(socket);
  });
}

function applyAction(socket, config, decision, host, port) {
  note(decision, `${host}:${port}`);
  if (decision.action === "reject") {
    failSocks(socket);
    return;
  }
  if (decision.action === "proxy") relayProxy(socket, config, host, port);
  else relayDirect(socket, host, port, config);
}

function refuse(session, reason) {
  try {
    session.writeFrame(`NO\n${reason}\n`);
    session.socket.end();
  } catch {
    session.socket.destroy();
  }
}

async function handleTunnel(socket, config) {
  if (linkOf(config).token.length < 8) {
    log("隧道拒绝：令牌不足 8 个字符");
    socket.destroy();
    return;
  }
  try {
    const session = await acceptLink(socket, config);
    const opened = (await session.readFrame()).toString("utf8");
    const match = opened.match(/^OPEN\n([^\r\n]+)\n(\d+)\n$/);
    if (!match) {
      refuse(session, "目标无效");
      return;
    }
    const host = match[1];
    const port = Number(match[2]);
    const decision = decide(config, { host, ip: isIp(host) ? host : "", port: String(port), network: "tcp" });
    if (decision.action === "reject" || decision.action === "bypass") {
      note(decision, `${host}:${port}`);
      refuse(session, decision.reason);
      return;
    }
    const verdict = await assessTarget(config, host, port);
    if (!verdict.ok) {
      note({ action: "reject", reason: verdict.reason }, `${host}:${port}`);
      refuse(session, verdict.reason);
      return;
    }
    const remote = dial(verdict.host, verdict.port, config);
    let up = false;
    remote.on("error", () => {
      if (!up) refuse(session, "拨号失败");
      remote.destroy();
    });
    remote.on("connect", () => {
      up = true;
      note({ action: "direct", reason: decision.reason }, `${host}:${port}`);
      try {
        session.writeFrame("OK\n");
        bridgePlain(session, remote);
      } catch {
        socket.destroy();
        remote.destroy();
      }
    });
  } catch (err) {
    log(`隧道拒绝 ${err.message || err}`);
    socket.destroy();
  }
}

async function findProcess(port) {
  if (platform() === "linux" || platform() === "android") {
    try {
      const hex = port.toString(16).toUpperCase().padStart(4, "0");
      let inode = "";
      for (const table of ["/proc/net/tcp", "/proc/net/tcp6"]) {
        if (!existsSync(table)) continue;
        for (const line of readFileSync(table, "utf8").split("\n")) {
          const parts = line.trim().split(/\s+/);
          if (parts.length < 10) continue;
          if ((parts[1].split(":")[1] || "").toUpperCase() === hex) {
            inode = parts[9];
            break;
          }
        }
        if (inode) break;
      }
      if (!inode || inode === "0") return "";
      for (const pid of readdirSync("/proc")) {
        if (!/^\d+$/.test(pid)) continue;
        let fds = [];
        try {
          fds = readdirSync(`/proc/${pid}/fd`);
        } catch {
          continue;
        }
        for (const fd of fds) {
          try {
            const target = readlinkSync(`/proc/${pid}/fd/${fd}`);
            if (target === `socket:[${inode}]`) {
              const comm = readFileSync(`/proc/${pid}/comm`, "utf8").trim();
              return comm;
            }
          } catch {
            /* next fd */
          }
        }
      }
    } catch {
      return "";
    }
  }
  if (platform() === "win32") {
    return await new Promise((resolve) => {
      execFile(
        "powershell.exe",
        ["-NoProfile", "-Command", `(Get-NetTCPConnection -RemotePort ${Number(port)} -ErrorAction SilentlyContinue | Select-Object -First 1).OwningProcess`],
        { timeout: 2500 },
        (err, stdout) => {
          const pid = String(stdout || "").trim();
          if (err || !/^\d+$/.test(pid)) return resolve("");
          execFile(
            "powershell.exe",
            ["-NoProfile", "-Command", `(Get-Process -Id ${pid} -ErrorAction SilentlyContinue).ProcessName`],
            { timeout: 2500 },
            (err2, out2) => resolve(err2 ? "" : String(out2 || "").trim()),
          );
        },
      );
    });
  }
  return "";
}

function handleSocks(socket, config) {
  socket._lexisSocks = true;
  let stage = 0;
  let pending = Buffer.alloc(0);
  const cap = linkOf(config).headerBytes;
  socket.on("data", (chunk) => {
    pending = Buffer.concat([pending, chunk]);
    if (pending.length > cap) {
      socket.destroy();
      return;
    }
    if (stage === 0) {
      if (pending.length < 2) return;
      const methods = pending[1];
      if (pending.length < 2 + methods) return;
      pending = pending.subarray(2 + methods);
      socket.write(Buffer.from([0x05, 0x00]));
      stage = 1;
    }
    if (stage !== 1) return;
    if (pending.length < 4) return;
    if (pending[1] !== 0x01) {
      socket._lexisReplied = true;
      socket.removeAllListeners("data");
      socket.end(Buffer.from([0x05, 0x07, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
      return;
    }
    const atyp = pending[3];
    let host = "";
    let port = 0;
    let offset = 4;
    if (atyp === 1) {
      if (pending.length < 10) return;
      host = [...pending.subarray(4, 8)].join(".");
      port = pending.readUInt16BE(8);
      offset = 10;
    } else if (atyp === 3) {
      const len = pending[4];
      if (pending.length < 5 + len + 2) return;
      host = pending.subarray(5, 5 + len).toString("utf8");
      port = pending.readUInt16BE(5 + len);
      offset = 7 + len;
    } else if (atyp === 4) {
      if (pending.length < 22) return;
      const words = [];
      for (let i = 0; i < 16; i += 2) words.push(pending.readUInt16BE(4 + i).toString(16));
      host = words.join(":");
      port = pending.readUInt16BE(20);
      offset = 22;
    } else {
      socket._lexisReplied = true;
      socket.removeAllListeners("data");
      socket.end(Buffer.from([0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
      return;
    }
    const rest = pending.subarray(offset);
    pending = Buffer.alloc(0);
    stage = 2;
    socket.pause();
    socket.removeAllListeners("data");
    if (rest.length) socket.unshift(rest);
    void (async () => {
      const processName = await findProcess(socket.remotePort);
      const decision = decide(config, { host, ip: isIp(host) ? host : "", process: processName, port: String(port), network: "tcp" });
      if (decision.action === "reject") {
        note(decision, `${host}:${port}`);
        socket._lexisReplied = true;
        socket.resume();
        socket.end(Buffer.from([0x05, 0x02, 0x00, 0x01, 0, 0, 0, 0, 0, 0]));
        return;
      }
      applyAction(socket, config, decision, host, port);
    })();
  });
  socket.on("error", () => socket.destroy());
}

function listenHost(config, inbound) {
  const listen = inbound.listen || "127.0.0.1";
  if (inbound.protocol === "tunnel") return listen;
  if (linkOf(config).allowLan) return listen;
  if (listen !== "127.0.0.1" && listen !== "::1") log(`${inbound.tag || inbound.protocol} 改绑 127.0.0.1`);
  return "127.0.0.1";
}

function serveInbound(config, inbound) {
  const host = listenHost(config, inbound);
  const server = createTcp((socket) => {
    if (!admit(socket, config)) return;
    arm(socket, config);
    if (inbound.protocol === "socks") {
      handleSocks(socket, config);
      return;
    }
    if (inbound.protocol === "tunnel") {
      void handleTunnel(socket, config);
      return;
    }
    void (async () => {
      const processName = await findProcess(socket.remotePort);
      const targetHost = inbound.targetHost;
      const targetPort = inbound.targetPort;
      const decision = decide(config, { host: targetHost, ip: isIp(targetHost) ? targetHost : "", process: processName, port: String(targetPort), network: "tcp" });
      applyAction(socket, config, decision, targetHost, targetPort);
    })();
  });
  server.on("error", (err) => {
    state.errors.push(`${inbound.tag} ${inbound.port}: ${err.message}`);
    log(`入站失败 ${inbound.tag}: ${err.message}`);
  });
  server.listen(inbound.port, host, () => {
    state.listeners.push(`${inbound.protocol} ${host}:${inbound.port}`);
    log(`监听 ${inbound.protocol} ${host}:${inbound.port}`);
  });
  return server;
}

function forwardScript(config) {
  const port = (config.inbounds || []).find((item) => item.protocol === "socks")?.port || config.inbounds?.[0]?.port || 1080;
  if (platform() === "win32") {
    const gateway = String(config.windows?.gateway || "10.7.0.1").replace(/[^0-9a-fA-F:.]/g, "") || "10.7.0.1";
  const winMethod = config.windows?.method === "windivert" ? "windivert" : "portproxy";
  return {
      file: "apply-forward.ps1",
      body: `$port = ${port}
$gateway = "${gateway}"
if ("${winMethod}" -eq "portproxy") {
  netsh interface portproxy add v4tov4 listenaddress=127.0.0.1 listenport=$port connectaddress=127.0.0.1 connectport=$port
  Write-Output "portproxy 只绑 127.0.0.1:$port，不向局域网公布"
} else {
  Write-Output "WinDivert 过滤已记录，网关 $gateway。驱动需要单独安装后由本进程的监听端口承接。"
}
`,
    };
  }
  if (platform() === "android") {
    const session = {
      method: "vpn",
      mtu: config.android?.mtu || 1500,
      address: config.android?.address || "10.7.0.2/32",
      dns: config.android?.dns || "1.1.1.1",
      routes: ["0.0.0.0/0"],
      bypass: (GEOIP.private || []).concat(["127.0.0.0/8"]),
      processes: config.processes || [],
    };
    return { file: "vpn-session.json", body: JSON.stringify(session, null, 2) };
  }
  const mark = config.linux?.mark || 255;
  const method = config.linux?.method === "tproxy" ? "tproxy" : "redirect";
  return {
    file: "apply-forward.sh",
    body: `#!/bin/sh
set -eu
PORT=${port}
MARK=${mark}
if [ "$(id -u)" -ne 0 ]; then
  echo "没有 root，规则留在本文件，未改系统转发"
  exit 0
fi
if [ "${method}" = "tproxy" ]; then
  iptables -t mangle -C PREROUTING -p tcp -j TPROXY --on-port "$PORT" --tproxy-mark "$MARK" 2>/dev/null || iptables -t mangle -A PREROUTING -p tcp ! -d 127.0.0.0/8 -j TPROXY --on-port "$PORT" --tproxy-mark "$MARK"
else
  iptables -t nat -N LEXIS 2>/dev/null || true
  iptables -t nat -F LEXIS
  iptables -t nat -A LEXIS -d 127.0.0.0/8 -j RETURN
  iptables -t nat -A LEXIS -p tcp -j REDIRECT --to-ports "$PORT"
  iptables -t nat -C OUTPUT -p tcp -j LEXIS 2>/dev/null || iptables -t nat -A OUTPUT -p tcp -j LEXIS
fi
echo "系统转发已指向 $PORT"
`,
  };
}

function applySystem(config) {
  if (config.mode !== "system-forward") {
    state.system = "固定端口模式，不改系统转发";
    return;
  }
  const script = forwardScript(config);
  const path = join(here, script.file);
  writeFileSync(path, script.body);
  if (script.file.endsWith(".sh")) {
    execFile("sh", [path], { timeout: 8000 }, (err, stdout, stderr) => {
      state.system = `${stdout || ""}${stderr || ""}${err ? err.message : ""}`.trim() || "已执行 Linux 转发脚本";
      log(state.system);
    });
    return;
  }
  if (script.file.endsWith(".ps1")) {
    execFile("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", path], { timeout: 8000 }, (err, stdout, stderr) => {
      state.system = `${stdout || ""}${stderr || ""}${err ? err.message : ""}`.trim() || "已执行 Windows 转发脚本";
      log(state.system);
    });
    return;
  }
  state.system = "已写出 vpn-session.json。Android 的 VpnService 读取这份会话；Termux 进程本身不能打开系统 VPN。";
  log(state.system);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (ch) => {
    const name = { "&": "amp", "<": "lt", ">": "gt", '"': "quot", "'": "#39" }[ch];
    return "&" + name + ";";
  });
}

function startStatus(config) {
  const server = createHttp((req, res) => {
    const up = Math.floor((Date.now() - started) / 1000);
    const rows = state.decisions
      .map((item) => `<li>${escapeHtml(new Date(item.at).toLocaleTimeString())} ${escapeHtml(item.action)} ${escapeHtml(item.host)} <span>${escapeHtml(item.reason)}</span></li>`)
      .join("");
    const body = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>词隙客户端</title>
<style>
body{margin:0;background:#10140f;color:#e7e4d8;font:16px/1.5 "Noto Sans SC",sans-serif}
main{max-width:40rem;margin:0 auto;padding:1.25rem}
h1{font-size:1.4rem;margin:0} .sage{color:#b7c4a4} .mist{color:#b4bbae}
section{border:1px solid #343c31;background:#1a2019;border-radius:.75rem;padding:1rem;margin-top:1rem}
ul{padding-left:1.1rem} li span{color:#b4bbae}
</style>
<main>
<h1>词隙 <span class="sage">客户端</span></h1>
<p class="mist">${escapeHtml(platform())} · 角色 ${escapeHtml(config.role)} · ${escapeHtml(config.mode === "system-forward" ? "系统接管" : "固定端口")}</p>
<section><p>已运行 ${up} 秒 · 心跳 ${state.beats}</p><p>${escapeHtml(state.listeners.join(" · ") || "还没有入站")}</p></section>
<section><p>${escapeHtml(state.system)}</p><p class="mist">${escapeHtml(state.resources)}</p></section>
<section><ul>${rows || "<li class='mist'>还没有连接</li>"}</ul></section>
</main>`;
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end(body);
  });
  server.listen(config.statusPort || 17890, config.statusHost || "127.0.0.1");
  return server;
}

function selfCheck() {
  const sample = {
    version: 1,
    processDefault: "proxy",
    processes: [{ name: "ssh", action: "bypass" }],
    rules: [
      { type: "GEOSITE", value: "cn", action: "direct" },
      { type: "GEOIP", value: "private", action: "direct" },
      { type: "MATCH", value: "", action: "proxy" },
    ],
    extras: "",
  };
  const a = decide(sample, { host: "www.baidu.com" });
  const b = decide(sample, { host: "example.com", process: "ssh" });
  const c = decide(sample, { ip: "10.0.0.8" });
  remoteGeosite = "only.remote.test\n";
  const d = decide(
    { ...sample, rules: [{ type: "GEOSITE", value: "remote", action: "reject" }, ...sample.rules] },
    { host: "a.only.remote.test" },
  );
  remoteGeosite = "";
  if (a.action !== "direct" || b.action !== "bypass" || c.action !== "direct" || d.action !== "reject") {
    console.error("self-check failed", a, b, c, d);
    process.exit(1);
  }
  if (!isBlockedAddress("127.0.0.1") || !isBlockedAddress("10.0.0.8") || !isBlockedAddress("169.254.169.254") || !isBlockedAddress("::1") || isBlockedAddress("8.8.8.8")) {
    console.error("address check failed");
    process.exit(1);
  }
  console.log("lexis-agent check ok");
}

async function main() {
  if (process.argv.includes("--check")) {
    selfCheck();
    return;
  }
  const config = loadConfig();
  state.config = config;
  await pullResources(config);
  mkdirSync(here, { recursive: true });
  writeFileSync(join(here, "lexis-agent.pid"), String(process.pid));
  for (const inbound of config.inbounds || []) serveInbound(config, inbound);
  applySystem(config);
  startStatus(config);
  const beat = () => {
    state.beats += 1;
    state.lastBeat = Date.now();
    writeFileSync(join(here, "lexis-agent.state.json"), JSON.stringify({ pid: process.pid, beats: state.beats, at: state.lastBeat, listeners: state.listeners }, null, 2));
    log(`debug 心跳 ${state.beats}`);
  };
  beat();
  const timer = setInterval(beat, Math.max(5, config.heartbeatSec || 15) * 1000);
  const stop = () => {
    clearInterval(timer);
    process.exit(0);
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  log(`词隙客户端常驻中，状态页 http://${config.statusHost || "127.0.0.1"}:${config.statusPort || 17890}/  家目录 ${homedir()}`);
}

function isDirectRun() {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return fileURLToPath(import.meta.url) === resolve(entry);
  } catch {
    return false;
  }
}

if (isDirectRun()) {
  main().catch((err) => {
    console.error(err);
    process.exit(1);
  });
}

export { isBlockedAddress, assessTarget, serveInbound, clientSession };
